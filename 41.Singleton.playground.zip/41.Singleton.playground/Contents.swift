import Foundation

// Singleton is a design pattern that ensures a class can have only one object
// An initializer allows us to instantiate an object of a class

class FileManager{
    static let fileObj = FileManager() // create a singleton
    private init() {
        // create a private initializer
    }
    func checkFileAccess(user: String) { // method to request file
      if user == ("bigkids.com") { // condition to check username
        print("Access Granted")
      }
      else {
        print("Access Denied")
      }
    }
}
let userName = "@example.com"
let file = FileManager.fileObj // access method
file.checkFileAccess(user: userName)
