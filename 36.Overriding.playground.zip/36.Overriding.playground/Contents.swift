import Foundation

class Vehicle {
  func displayInfo() { // method in the superclass
    print("Four Wheeler or Two Wheeler")
  }
}
class Car: Vehicle { // Car inherits Vehicle
  override func displayInfo() {
    print("Four Wheeler")
  }
}
var car1 =  Car() // create an object of the subclass
car1.displayInfo()

// Access Overridden Method
class Vehicle2 {
  func displayInfo2() { // method in the superclass
    print("Vehicle: Four Wheeler or Two Wheeler")
  }
}

// Car inherits Vehicle
class Car2: Vehicle2 {
  override func displayInfo2() {
    super.displayInfo2() // access superclass
    print("Car: Four Wheeler")
  }
}
var car3 =  Car2() // create an object of the subclass
car3.displayInfo2() // call the displayInfo() method

// Prevent Method Overriding -> use Final
class Vehicle3 {
  final func displayInfo3() { // prevent overriding
    print("Four Wheeler or Two Wheeler")
  }
}
/*
class Car3: Vehicle3 { // Car inherits Vehicle
  override func displayInfo3() { // attempt to override
    print("Four Wheeler")
  }
}
var car4 =  Car3() // create an object of the subclass
car4.displayInfo3()
 */

// Override Swift Properties
class University {
    var cost: Int { // computed property
    return 5000
  }
}
class Fee: University {
    override var cost: Int { // override computed property
    return 10000
  }
}
var amount = Fee()
print("New Fee:", amount.cost) // access fee property
