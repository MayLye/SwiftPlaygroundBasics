import Foundation

// Loop Over Array: access items of an array
let languages = ["Swift", "Java", "Go", "JavaScript"]
for language in languages {
      print(language)
}

// remove item from an array
for language in languages where language != "Java"{
  print(language)
}

// Range: iterate from i = 1 to i = 3
var values = 1...3
for i in 1...3 {
    print(i)
}

// fStride Function
for i in stride(from: 1, to: 10, by: 2) {
    print(i)
}
