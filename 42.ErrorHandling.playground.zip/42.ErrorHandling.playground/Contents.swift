import Foundation

/*
 1.Create an enum that represents the types of errors:
 enum DivisionError: Error {
   case dividedByZero
 }
 */

/*
 2.Create a throwing function using the throws keyword:
 // create throwing function using throws keyword
 func division(numerator: Int, denominator: Int) throws {
 // throw error if divide by 0
   if denominator == 0 {
     throw DivisionError.dividedByZero
   }
 }
 */

/*
 3.Call the function using the try keyword:
 // call throwing function using try keyword
 try division(numerator: 10, denominator: 0)
 */

/*
 4. Handling Errors Using do-catch Statement:
 do {
   try division(numerator: 10, denominator: 0)
 }
 catch DivisionError.dividedByZero {
   // statement
 }
 */

// Error Handling: create an enum with error values
enum DivisionError: Error {
  case dividedByZero
}
// create a throwing function using throws keyword
func division(numerator: Int, denominator: Int) throws {
  if denominator == 0 { // throw error if divide by 0
    throw DivisionError.dividedByZero
  }
  else {
    let result = numerator / denominator
    print(result)
  }
}
do { // call throwing function from do block
  try division(numerator: 10, denominator: 0)
  print("Valid Division")
}
catch DivisionError.dividedByZero { // catch error if function throws an error
  print("Error: Denominator cannot be 0")
}


// Disable Error Handling
enum DivisionError2: Error {
  case dividedByZero2
}
func division2(numerator: Int, denominator: Int) throws {
  if denominator == 0 {
    throw DivisionError2.dividedByZero2
  }
  else {
    let result2 = numerator / denominator
    print("Result:", result2)
  }
}
try! division2(numerator: 10, denominator: 5)
