import Foundation

// protocol defines a blueprint of methods or properties
protocol Greet {
  var name: String { get } // blueprint of property
  func message() // blueprint of a method
}
class Employee: Greet { // conform class to Greet protocol
  var name = "Perri" // implementation of property
  func message() { // implementation of method
    print("Good Morning", name)
  }
}
var employee1 = Employee()
employee1.message()


// Protocol To Calculate Area
protocol Polygon {
  func getArea(length: Int, breadth: Int)
}
class Rectangle: Polygon { // conform the Polygon protocol
  func getArea(length: Int, breadth: Int) { // implementation of method
    print("Area of the rectangle:", length * breadth)
  }
}
var r1 = Rectangle() // create an object
r1.getArea(length:5, breadth:6)


// Conforming Multiple Protocols
protocol Sum { // create Sum protocol
  func addition()
}
protocol Multiplication { // create Multiplication protocol
  func product()
}
class Calculate: Sum, Multiplication { // conform class to two protocols
  var num1 = 0
  var num2 = 0
  func addition () {
    let result1 = num1 + num2
    print("Sum:", result1)
  }
  func product () {
    let result2 = num1 * num2
    print("Product:", result2)
  }
}
var calc1 = Calculate() // create an object
calc1.num1 = 5  // assign values to properties
calc1.num2 = 10
calc1.addition() // access methods
calc1.product()


// Protocol Inheritance
protocol Car {
  var colorOptions: Int { get }
}

// inherit Car protocol
protocol Brand: Car {
  var name: String { get }
}
class Mercedes: Brand { // must implement properties of both protocols
  var name: String = ""
  var colorOptions: Int = 0
}
var car1 = Mercedes()
car1.name = "Mercedes AMG"
car1.colorOptions = 4
print("Name:", car1.name)
print("Color Options:", car1.colorOptions)


// Protocol Extensions
protocol Brake { // protocol definition
  func applyBrake()
}
class Car2: Brake { // define class that conforms Brake
  var speed2: Int = 0
  func applyBrake() {
    print("Brake Applied")
  }
}
extension Brake { // extend protocol
  func stop() {
    print("Engine Stopped")
  }
}
let car2 = Car2()
car2.speed2 = 61
print("Speed:", car2.speed2)
car2.applyBrake()
car2.stop() // access extended protocol
