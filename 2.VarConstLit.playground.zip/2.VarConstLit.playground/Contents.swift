import Foundation

// Variable is a container (storage area) to hold data

var num = 10 // num is a variable storing the value 10.

/*
var siteName:String
var id: Int
 */
// siteName is a variable of type String
// id is a variable of Int type

var siteName: String
siteName = "bigkidsapps.com"
print(siteName)

var siteName2 = "bigkidsapps.com"
print(siteName2) // bigkidsapps.com
siteName2 = "apple.com" // assigning a new value to siteName2
print(siteName2)
// value of siteName is changed from "bigkidsapps.com" to "apple.com"
// constant is a special type of variable whose value cannot be changed

let x = 5
print(x)

// Literals are representations of fixed values in a program.
// types include Integer, floating-point, boolean, string and character
let range = 20  // Integer Literals
let piValue: Float = 3.14 // Floating-point literals
let pass: Bool = true // Boolean Literals

// String and Character Literals
let someCharacter: Character = "S"
let someString: String = "Swift is fun" 
