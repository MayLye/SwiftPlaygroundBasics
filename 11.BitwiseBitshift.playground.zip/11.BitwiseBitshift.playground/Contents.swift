import Foundation

/*
 &    Bitwise AND   a & b
 |    Bitwise OR    a | b
 ^    Bitwise XOR   a ^ b
 ~    Bitwise NOT   ~ a
 <<   Bitwise Shift Left    a << b
 >>   Bitwise Shift Right   a >> b
 */

// AND
/*
 12 = 00001100 (In Binary)
 25 = 00011001 (In Binary)

      00001100
 &    00011001
 _____________
      00001000  = 8 (In Decimal)
 */
var a = 12
var b = 25
var result = a & b
print (result)

var result2 = a | b // OR
print(result2)

var result3 = a ^ b // XOR
print(result3)

var result4 = ~b // NOT
print(result4)

var result5 = a << 2 // shift
print(result5)
var result6 = a >> 2 // shift
print(result6)
