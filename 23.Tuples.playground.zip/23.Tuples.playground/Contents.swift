import Foundation

// create tuple with two elements
var product = ("MacBook", 1099.99)
// access tuple elements
print("Name:", product.0)
print("Price:", product.1)

// Modify Tuple Element
print("Original Tuple: ")
product.1 = 1499.99 // modify second value
print("\nTuple After Modification: ")
print("Name:", product.0)
print("Price:", product.1)

// named tuple
var company = (product: "Big Kids App", version: 2.1)
print("Product:", company.product)
print("Version:", company.version)

// Nested Tuple
var alphabets = ("A", "B", "C", ("a", "b", "c"))
print(alphabets.0)
print(alphabets.3)
print(alphabets.3.0)

// Dictionary Inside a Tuple
var laptopLaunch = ("MacBook", 1299, ["Hong Kong": "10 PM", "USA": "10 AM"])
print(laptopLaunch.2)
laptopLaunch.2["Canada"] = "11 AM"
print(laptopLaunch.2)
