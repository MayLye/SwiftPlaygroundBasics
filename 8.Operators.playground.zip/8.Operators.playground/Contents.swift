import Foundation

print(5 + 6)   // 11

// arithmetic operators
var a = 7
var b = 2
print (a + b)
print (a - b)
print (a * b)
print (a / b)
print (a % b)

// assignment operators
var c = 10  // assign 10 to c
var d = 5   // assign 5 to d
c += d      // c = c + d
print(c)

// Comparison Operators
var e = 5, f = 2
print(e == f)   // equal to operator
print(e != f)   // not equal to operator
print(e > f)    // greater than operator
print(e < f)    // less than operator
print(e >= f)   // greater than or equal to operator
print(e <= f)   // less than or equal to operator

// Logical Operators
print(true && true)      // logical AND
print(true && false)     // logical AND
print(true || false)     // logical OR
print(!true)             // logical NOT

// bitwise operators
/*
&    Binary AND
|    Binary OR
^    Binary XOR
~    Binary One's Complement
<<    Binary Shift Left
>>    Binary Shift Right
 */

// Other Operators
/*
? : Ternary Operator - returns value based on the condition
??  Nil-Coalescing Operator - checks whether an optional contains a value or not
... Range Operator - defines range containing values
 */
