import Foundation

// data types specify the type of data that can be stored inside a variable
// Swift Data Types include Character, String, Integer, Float, Double and Boolean

// character data type -> single-character string
var letter: Character = "s"
print(letter)

// string data type -> textual data
var language: String = "swift"
print(language)

// integer data type -> a whole number with no fractional component
var number: Int = 3
print(number)

// boolean data type -> logical entities.
let passCheck: Bool = true
print(passCheck)
let failCheck: Bool = false
print(failCheck)

// float data type -> a number with a fractional component. represents a 32-bit floating-point number. precision can be as little as 6 decimal digits.
let piValue: Float = 3.14
print(piValue)

// double data type -> a number with fractional components. 64-bit floating-point number. precision of at least 15 decimal digits.
let latitude: Double = 27.7007697012432
print(latitude)
