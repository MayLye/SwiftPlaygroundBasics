import Foundation

for numbers in 1...4 { // Closed Range
  print(numbers)
}

for numbers in 1..<4 { // Half-Open Range
  print(numbers)
}

// One-sided Range
let range1 = ..<2   // ..< operator
print(range1.contains(-1))  // check if -9 is in the range
let range2 = 2...   // ... operator
print(range2.contains(33))  // check if 33 is in the range

// Access Array Elements
let languages = ["Swift", "Java", "C"]
print(languages[0...2])
