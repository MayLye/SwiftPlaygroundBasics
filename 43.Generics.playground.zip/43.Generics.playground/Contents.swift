import Foundation

// Generics allows us to create a single function and class (or any other types) that can be used with different data types.

// generic function
func displayData<T>(data: T) {
print("Generic Function:")
print("Data Passed:", data)
}
displayData(data: "Swift") // working with String
displayData(data: 5) // working with Int

// generic class
class Information<T> {
  var data: T // property of T type
  init (data: T) {
    self.data = data
  }
  func getData() -> T { // method that return T type variable
    return self.data
  }
}
// with Int data
var intObj = Information<Int>(data: 6)
print("Generic Class returns:", intObj.getData())

// with String data
var strObj = Information<String>(data: "Swift")
print("Generic Class returns:", strObj.getData())

// Type Constraints
func addition<T: Numeric>(num1: T, num2: T) {
  print("Sum:", num1 + num2)
}
addition(num1: 5, num2: 10) // pass Int value
addition(num1: 5.5, num2: 10.8) // pass Double value
