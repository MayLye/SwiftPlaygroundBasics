import Foundation

// program to find the day of the week
// Switch Statement with fallthrough, the control proceeds to the next case even if the case value does not match with the switch expression
let dayOfWeek = 4
switch dayOfWeek {
  case 1:
    print("Sunday")
  case 2:
    print("Monday")
  case 3:
    print("Tuesday")
  case 4:
    print("Wednesday")
    fallthrough
  case 5:
    print("Thursday")
  case 6:
    print("Friday")
  case 7:
    print("Saturday")
  default:
    print("Invalid day")
}

// Switch Statement with Range
let ageGroup = 33
switch ageGroup {
  case 0...16:
    print("Child")
  case 17...30:
    print("Young Adults")
  case 31...45:
    print("Middle-aged Adults")
  default:
    print("Old-aged Adults")
}

// Tuple in Switch Statement
let info = ("Dwarf", 38)
switch info {
  case ("Dwarf", 38):
    print("Dwarf is 38 years old")
  case ("Elf", 46):
    print("Elf is 46 years old")
  default:
    print("Not known")
}
