import Foundation

// Swift "Hello, World!" Program
print("Hello, World!") 
