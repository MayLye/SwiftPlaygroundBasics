import Foundation

class Animal { // Parent class
  var name: String = ""
  func eat() {
    print("I can eat")
  }
}
// colon : to inherit a class from another class
class Dog: Animal { // inherit from Animal
  func display() { // new method in subclass
    print("My name is ", name); // access name property of superclass
  }
}
var labrador = Dog() // create an object of the subclass
// access superclass property and method
labrador.name = "Baby"
labrador.eat()

labrador.display() // call subclass method

// Method Overriding
class Animal2 {
 func eat2() { // method in the superclass
   print("I can eat")
   }
}
class Dog2: Animal2 { // Dog inherits Animal
  // subclass overrides the method in the superclass
  override func eat2() { // overriding the eat() method
    print("I eat dog food")
    }
}
var labrador2 =  Dog2() // create an object of the subclass
labrador2.eat2() // call the eat() method

// super Keyword in Swift Inheritance
class Animal3 {
  func eat3() { // create method in superclass
    print("I can eat")
  }
}
class Dog3: Animal3 { // Dog inherits Animal
  // access the superclass method from the subclass
  override func eat3() { // overriding the eat() method
  super.eat3() // call method of superclass
  print("I eat dog food")
  }
}
var labrador3 =  Dog3() // create an object of the subclass
labrador3.eat3() // call the eat() method


// Benefits of Inheritance
class RegularPolygon {
    func calculatePerimeter(length: Int, sides: Int) {
      let result = length * sides
      print("Perimeter:", result )
    }
}
class RegularSquare: RegularPolygon { // inherit Square from Polygon
var length = 0
var sides = 0
    func calculateArea() {
       let area = length * length
       print("Regular Square Area:", area)
    }
}
class RegularTriangle: RegularPolygon { // inherit Pentagon from Polygon
var length = 0.0
var sides = 0.0
    func calculateArea() {
       let area = (sqrt(3)/4) * (length * length)
       print("Regular Triangle Area:", area)
    }
}
var shape = RegularSquare()
shape.length = 4
shape.calculateArea()
// area = length*length = 4x4 =16
shape.calculatePerimeter(length: 3,sides:4)
// perimater = length*side = 3*4

var shape2 = RegularTriangle()
shape2.length = 2
shape2.calculateArea()
// area = (sqrt(3)/4)*(length*length) = (sqrt(3)/4)*(2*2) = 1.732
shape2.calculatePerimeter(length: 2,sides:3)
// perimater = length*side = 2*3 = 6
