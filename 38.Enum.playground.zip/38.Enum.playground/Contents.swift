import Foundation

// an enum is a user-defined data type that has a fixed set of related values.
enum Season { // define enum
  case spring, summer, autumn, winter // define enum values
}
var currentSeason: Season // create enum variable
currentSeason = Season.summer // assign value to enum variable
print("Current Season:", currentSeason)


// enum With Switch Statement
enum PizzaSize {
  case small, medium, large
}
var size = PizzaSize.medium

switch(size) {
  case .small:
    print("I ordered a small size pizza.")
  case .medium:
    print("I ordered a medium size pizza.")
   case .large:
    print("I ordered a large size pizza.");
}


// Iterate Over enum Cases
enum Season2: CaseIterable { // conform Languages to caseIterable
  case spring, summer, autumn, winter
}
for currentSeason in Season2.allCases { // for loop to iterate over all cases
  print(currentSeason)
}


// with rawValue
enum Size : Int {
  case small = 10
  case medium = 12
  case large = 14
}
var result = Size.small.rawValue // access raw value of python case
print(result)


// Associated Values
enum Laptop {
  case name(String) // associate string value
  case price (Int) // associate integer value
}
var brand = Laptop.name("Lenovo") // pass string value to name
print(brand)
var offer = Laptop.price(1599) // pass integer value to price
print(offer)
