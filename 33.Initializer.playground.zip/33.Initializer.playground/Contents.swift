import Foundation

class  Wall { // declare a class
  var length: Double
  init() { // initializer to initialize property
    length = 5.5
    print("Creating a wall.")
    print("Length = ", length)
  }
}
var wall1 = Wall() // create an object

// Parameterized Initializer
class Walle {
  var length: Double
  var height: Double
  init(length: Double, height: Double) { // initialize properties
    self.length = length
    self.height = height
  }
  func calculateArea() -> Double {
    return length * height
  }
}
// create object and initialize data members
var walle1 = Walle(length: 10.5, height: 8.6)
var walle2 = Walle(length: 8.5, height: 6.3)
print("Area of Walle 1: ", walle1.calculateArea())
print("Area of Walle 2: ", walle2.calculateArea())

// Initializer Overloading
class Person {
  var age: Int
  init() { // 1. initializer with no arguments
    age = 20
  }
  init(age: Int) { // 2. initializer with an argument
    self.age = age
  }
  func getAge() -> Int { // method to return age
    return age
  }
}
var person1 = Person()
var person2 = Person(age: 23)
print("Person1 Age:", person1.getAge())
print("Person1 Age:", person2.getAge())

// convenience Initializer
class University {
  var name : String
  var rank : String
  init(name : String, rank: String) {
    self.name = name
    self.rank = rank
  }
  convenience init() { // define convenience init
    self.init(name: "ABC University", rank: "1st")
  }
}
var university1 = University()
print(university1.name)
print("Rank:", university1.rank)

// Failable Initializer
class File {
  var folder: String
  init?(folder: String) {
    if folder.isEmpty { // check if empty
      print("Folder Not Found") // 1st output
      return nil
    }
    self.folder = folder
  }
}
var file = File(folder: "") // create folder1 object
if (file != nil) {
  print("File Found Successfully")
}
else {
  print("Error Finding File") // 2nd output
}

// Memberwise Initializer for structs
struct Person2 {
  // define two properties
  var name: String
  var age: Int
}
var person3 = Person2( name: "Dwarf", age: 43) // object
print("Name:", person3.name)
print("Age:", person3.age)
