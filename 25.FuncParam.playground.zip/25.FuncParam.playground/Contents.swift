import Foundation

func addNumbers2(c: Int, d: Int) {
    let sum2 = c + d
    print("Sum:", sum2)
}
addNumbers2(c: 2, d: 3)

func addNumbers( a: Int = 7,  b: Int = 8) { // with Default Values
  let sum = a + b
  print("Sum:", sum)
}
addNumbers(a: 2, b: 3)  // function call with two arguments
addNumbers(a: 2)    // function call with one argument
addNumbers()    // function call with no arguments

// Omit Argument Labels
func sum(_ a: Int, _ b: Int) {
  print("Sum:", a + b)
}
sum(2, 3)

// Function with variadic parameters: program to find sum of multiple numbers
func sum(numbers: Int...) {
  var result = 0
  for num in numbers {
    result = result + num
  }
  print("Sum = \(result)")
}
sum(numbers: 1, 2, 3) // function call with 3 arguments
sum(numbers: 4, 9) // function call with 2 arguments

// inout Parameters
func changeName(name: inout String) {
  if name == "Ross" {
      name = "Joey"
  }
}
var userName = "Ross"
print("Before: ", userName)
changeName(name: &userName)
print("After: ", userName)

// Return Values
func addNumbers3(a: Int, b: Int) -> Int {
  let sum3 = a + b
  return sum3
}
let result2 = addNumbers3(a: 2, b: 3)
print("Sum:", result2)

// Multiple Return Values
func compute(number3: Int) -> (Int, Int, Int) {
  let square = number3 * number3
  let cube = square * number3
  return (number3, square, cube)
}
var result = compute(number3: 5)
print("Number:", result.0)
print("Square:", result.1)
print("Cube:", result.2)
