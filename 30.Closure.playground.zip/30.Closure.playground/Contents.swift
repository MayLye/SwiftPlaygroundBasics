import Foundation

// Swift Closure
var greet = {   // declare a closure
  print("Hello, World!")
}
greet() // call the closure

// Closure Parameters
let greetUser = { (name: String)  in // closure that accepts one parameter
    print("Hey there, \(name).")
}
greetUser("Hola") // closure call

// Closure That Returns Value
var findSquare = { (num: Int) -> (Int) in  // closure definition
  let square = num * num
  return square
}
var result = findSquare(3) // closure call
// square = num*num = 3*3 = 9
print("Square:",result)

// Closures as Function Parameter
func grabLunch(search: ()->()) { // define a function and pass closure
  print("Let's go out for lunch")
  search() // closure call
}
grabLunch(search: { // pass closure as a parameter
   print("Alfredo's Pizza: 2 miles away")
})

// Trailing Closure
func grabLunch(message: String, search: ()->()) {
   print(message)
   search()
}
grabLunch(message:"Let's go out for lunch")  { // use of trailing closure
  print("Alfredo's Pizza: 2 miles away")
}

// Autoclosure
func display(greet: @autoclosure () -> ()) { // define a function with automatic closure
 greet()
}
display(greet: print("Hello World!")) // pass closure without {}
