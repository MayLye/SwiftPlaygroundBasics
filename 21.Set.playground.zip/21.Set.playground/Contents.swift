import Foundation

// create a set of integer type
var studentID : Set = [112, 114, 116, 118, 115]
print("Student ID: \(studentID)")

// Add Elements to a Set
var employeeID: Set = [21, 34, 54, 12]
print("Initial Set: \(employeeID)")
employeeID.insert(32) // using insert method
print("Updated Set: \(employeeID)")

// Remove an Element from a Set
var languages: Set = ["Swift", "Java", "Python"]
print("Initial Set: \(languages)")
let removedValue = languages.remove("Java") // remove Java from a set
print("Set after remove(): \(languages)")

// Iterate Over a Set
let fruits: Set = ["Apple", "Peach", "Mango"]
print("Fruits:")
for fruit in fruits { // for loop to access each fruits
  print(fruit)
}

// Find Number of Set Elements
let evenNumbers = [2,4,6,8]
print("Set: \(evenNumbers)")
print("Total Elements: \(evenNumbers.count)") // find number of elements

// Union of Two Sets
let setA: Set = [1, 3, 5] // first set
print("Set A: ", setA)
let setB: Set = [0, 2, 4] // second set
print("Set B: ", setB)
print("Union: ", setA.union(setB)) // perform union operation

// Intersection between Two Sets
let setA2: Set = [1, 3, 5] // first set
print("Set A: ",  setA2)
let setB2: Set = [1, 2, 3] // second set
print("Set B: ",  setB2)
print("Intersection: ", setA2.intersection(setB2)) // perform intersection operation

// Difference between Two Sets
let setA3: Set = [2, 3, 5] // first set
print("Set A: ",  setA3)
let setB3: Set = [1, 2, 6] // second set
print("Set B: ",  setB3)
print("Subtraction: ", setA3.subtracting(setB3)) // perform subtraction operation

// Symmetric Difference between Two Sets
let setA4: Set = [2, 3, 5] // first set
print("Set A: ",  setA4)
let setB4: Set = [1, 2, 6] // second set
print("Set B: ",  setB4)
print("Symmetric Difference: ", setA4.symmetricDifference(setB4)) // perform symmetric difference operation

// Check Subset of a Set
let setA5: Set = [1, 2, 3, 5, 4] // first set
print("Set A: ",  setA5)
let setB5: Set = [1, 2] // second set
print("Set B: ",  setB5)
print("Subset: ", setB5.isSubset(of: setA5)) // check if setB is subset of setA or not

// Check if two sets are equal
let setA6: Set = [1, 3, 5]
let setB6: Set = [3, 5, 1]
if setA6 == setB6 {
  print("Set A and Set B are equal")
}
else {
  print("Set A and Set B are different")
}

// Create an Empty Set
var emptySet = Set<Int>()
print("Set:", emptySet)
