import Foundation

class Race { // declare a class
  var laps: Int
  init() { // define initializer
    laps = 5
    print("Race Completed")
    print("Total laps:", laps)
  }
  deinit { // define deinitializer
    print("Memory Deallocated")
  }
}
var result: Race? = Race() // create an instance
result = nil  // deallocate object
