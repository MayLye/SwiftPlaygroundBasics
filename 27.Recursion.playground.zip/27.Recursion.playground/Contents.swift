import Foundation

func countDown(number: Int) { // program to count down number to 0
  print(number)  // display the number
  if number == 0 { // condition to break recursion
    print("Countdown Stops")
  }
  else { // condition for recursion call
    countDown(number: number - 1) // decrease the number value
  }
}
print("Countdown:")
countDown(number:3)

// Find factorial of a number
func factorial(num: Int) -> Int {
  if num == 0 { // condition to break recursion
    return 1
  }
  else { // condition for recursive call
    return num * factorial(num: num - 1)
    // factorial=3*(3-1)=3*2=6
  }
}
var number = 3
var result = factorial(num: number) // function call
print("The factorial of 3 is", result)
