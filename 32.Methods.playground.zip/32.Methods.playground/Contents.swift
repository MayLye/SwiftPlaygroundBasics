import Foundation

class Person { // define a method
  func greet() {
    print("Hey there!")
  }
}
var nick = Person()
nick.greet() // call method

// Calculate Area and Volume
class Hall { // create a class
  var length = 0.0
  var breadth = 0.0
  var height = 0.0
  func calculateArea() { // method to calculate area
    print("Area of Hall =", length * breadth)
  }
  func calculateVolume() { // method to calculate volume
    print("Volume of Hall =", length * breadth * height)
  }
}
var hall1 = Hall() // create object of Hall class
hall1.length = 42.5
hall1.breadth = 30.8
hall1.height = 45.2
hall1.calculateArea() // call calculateArea() method
hall1.calculateVolume() // call calculateVolume() method

class Calculator {
  func multiply(num1: Int, num2: Int) -> Int { // non-static
    return num1 * num2
  }
  static func add(num1: Int, num2: Int) -> Int { // static
    return num1 + num2
   }
}
var obj = Calculator() // create an instance
var result2 =  Calculator.add(num1: 2, num2: 3) // call static
print("2 + 3 =", result2)
var result1 = obj.multiply(num1: 2,num2: 2) // call non-static
print("2 * 2 =", result1)

// self property
class Marks {
  var physics = 0
  func checkEligibility(physics: Int) {
    if (self.physics < physics) { // using self property
        // self refers to student1, 28<50
      print("Not Eligible for admission")
    }
    else {
      print("Eligible for admission")
    }
  }
}
var student1 = Marks()
student1.physics = 28
student1.checkEligibility(physics: 50)

// mutating Methods
struct Employee {
  var salary = 0
  mutating func salaryIncrement(increase: Int) { // define mutating function
  salary = salary + increase // modify salary property
  print("Increased Salary:",salary)
    // increased salary: 20000+5000
  }
}
var employee1 = Employee()
employee1.salary = 20000
employee1.salaryIncrement(increase: 5000)
