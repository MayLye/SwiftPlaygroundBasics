import Foundation

// expression is a combination of variables, operators, literals, and functions
var marks = 80// assign value to marks

// compare num1 and num2
let num1 = 10
let num2 = 20
var result = (num1 == num2)

// statements
var score = 9 * 5 // simple

var age = 25
if (age > 18) { // conditional
  print("Can Vote")
}

for _ in 1...3 { // loop
    print("Hello, World!")
}

var i = 1, n = 5 // while loop to display numbers from 1 to 5
while (i <= n) {
  print(i)
   i = i + 1
}

var currentLevel:Int = 0, finalLevel:Int = 5 // while Loop to Display Game Level
let gameCompleted = true
while (currentLevel <= finalLevel) {
  if gameCompleted {
    print("You have passed level \(currentLevel)")
      currentLevel += 1
  }
}
print("Level Ends")

// Infinite while Loop
/*
while (true) {
    print("Endless Loop")
}
 */

// code block is a group of statements (zero or more) that is enclosed in curly braces { }
if true { // start of block
    let sum = 2+3
    print("Result is \(sum)")
} // end of block
