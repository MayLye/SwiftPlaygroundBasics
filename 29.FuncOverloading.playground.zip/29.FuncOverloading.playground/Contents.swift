import Foundation

// with Different Parameter Types
func displayValue(value: Int) { // function with Int type parameter
    print("Integer value:", value)
}
func displayValue(value: String) { // function with String type parameter
    print("String value:", value)
}
displayValue(value: "Swift") // function call with String type parameter
displayValue(value: 2) // function call with Int type parameter

// with Different Number of Parameters
func display(number1: Int, number2: Int) { // function with two parameters
   print("1st Integer: \(number1) and 2nd Integer: \(number2)")
}
func display(number: Int) { // function with a single parameter
   print("Integer number: \(number)")
}
display(number: 5) // function call with single parameter
display(number1: 6, number2: 8) // function call with two parameters

// overloading with Argument Label
func display(person1 age:Int) {
    print("Person1 Age:", age)
}
func display(person2 age:Int) {
    print("Person2 Age:", age)
}
display(person1: 25)
display(person2: 38)
