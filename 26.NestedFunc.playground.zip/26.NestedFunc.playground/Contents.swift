import Foundation

// Nested Function
func greetMessage() {  // outer function
  func displayName() {  // inner function
    print("Good Morning Abraham!")
  }
  displayName() // calling inner function
}
greetMessage() // calling outer function

// Nested Function with Parameters
func addNumbers() { // outer function
  print("Addition")
  func display(num1: Int, num2: Int) {  // inner function
      print("5 + 10 =", num1 + num2)
  }
  display(num1: 5, num2: 10)    // calling inner function with two values
}
addNumbers()    // calling outer function

// with Return Values
func operate(symbol: String) -> (Int, Int) -> Int {
  func add(num1:Int, num2:Int) -> Int { // inner function to add two numbers
    return num1 + num2
  }
  func subtract(num1:Int, num2:Int) -> Int { // inner function to subtract two numbers
    return num1 - num2
  }
  let operation = (symbol == "+") ?  add : subtract
  return operation
}
let operation = operate(symbol: "+")
let result = operation(8, 3)
print("Result:", result)
