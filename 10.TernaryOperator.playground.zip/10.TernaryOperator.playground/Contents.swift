import Foundation

// Ternary Operator ?:
let marks = 60  // program to check pass or fail
let result = (marks >= 40) ? "pass" : "fail"
print("You " + result + " the exam")

// ternary operator to check the number is positive or negative
let num2 = 15
let result2 = (num2 > 0) ? "Positive Number" : "Negative Number"
print(result2)

// program to check if a number is positive, zero, or negative
let num3 = 7
let result3 = (num3 == 0) ? "Zero" : ((num3 > 0) ? "Positive" : "Negative")
print("The number is \(result3).")
