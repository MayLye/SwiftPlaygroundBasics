import Foundation

var i = 2
while (i <= 10) {
// guard condition to check the even number
// odd, i % 2 == 0 evaluates to false, guard is executed.
// even, i % 2 == 0 evaluates to true, guard is skipped.
  guard i % 2 == 0 else {
     i = i + 1
    continue
  }
  print(i)
  i = i + 1
}

// guard inside a Function
func checkOddEven() {
  let number = 23
  // use of guard statement
  guard number % 2 == 0 else {
    print("Odd Number")
    return
  }
  print("Even Number")
}
// function call
checkOddEven()

// guard with multiple conditions
func checkJobEligibility() {
  let age = 33
  guard age >= 18, age <= 40 else {
    print("Not Eligible for Job")
    return
  }
  print("You are eligible for this job")
}
checkJobEligibility()

// guard-let
func checkAge() {
  let age: Int? = 22
  guard let myAge = age else {
    print("Age is undefined")
    return
  }
  print("My age is \(myAge)")
}
checkAge()

// guard Vs if
func voteEligibility() {
  let age = 42
  if age >= 18 {
    print("Eligible to vote")
  }
  else {
    print("Not eligible to vote")
  }
}
voteEligibility()
