import Foundation

// Character data type -> a single-character string
var letter: Character = "H"
print(letter)
var symbol: Character = "@"
print(symbol)

// a string is used to store textual data
let name: String = "Swift"
print(name)
let message = "I love Swift."
print(message)

// compare two string
let str1 = "Hello, world!"
let str2 = "I love Swift."
let str3 = "Hello, world!"
print(str1 == str2)
print(str1 == str3)

// Join Two Strings
var greet2 = "Hello "
var name2 = "Jack"
greet2.append(name2)
print(greet2)

// Concatenate Using + and +=
var greet3 = "Hello, "
let name3 = "John"
var result = greet3 + name3
print(result)
greet3 += name3
print(greet3)

// count property to find the length of a string
let message2 = "Hello, World!"
print(message2.count)

// escape
var example = "This is \"String\" class"
print(example)

// Interpolation
let name4 = "Swift"
var message3 = "This is \(name4) programming."
print(message3)

// multiline string, add triple double quotes"""
var str: String = """
Swift is awesome
I love Swift
"""
print(str)
