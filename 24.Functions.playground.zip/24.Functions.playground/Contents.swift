import Foundation

// declare a function
func greet() {
  print("Hello World!")
}
greet() // call the function
print("Outside function")

// Function Parameters
func addNumbers(num1: Int, num2: Int) { // adds two numbers
  let sum = num1 + num2
  print("Sum: ", sum)
}
addNumbers(num1: 3, num2: 4) // calling functio

// Return Type
func findSquare (num: Int) -> Int { // function definition
  let result = num * num
  return result
}
var square = findSquare(num: 3) // function call
print("Square:",square)

// Add Two Numbers
func addNumbersA(num1: Int, num2: Int) -> Int { // adds two numbers
  let sum = num1 + num2
  return sum
}
var resultA = addNumbersA(num1: 3, num2: 4) // calling function
print("Sum: ", resultA)

// Library Function
var squareRoot = sqrt(25)
print("Square Root of 25 is",squareRoot)
var power = pow(2, 3) // pow() computes the power
print("2 to the power 3 is",power)

// Benefits of Using Functions
func getSquare(num: Int) -> Int{ // function definition
   return num * num
 }
for i in 1...3 {
  let result = getSquare(num: i) // function call
  print("Square of \(i) =",result)
}
