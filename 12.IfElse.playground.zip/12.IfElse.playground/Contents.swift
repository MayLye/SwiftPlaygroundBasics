import Foundation

// switch if
let number = 10
if (number > 0) {
  print("Number is positive.")
}
print("The if statement is easy")

// switch if else
if (number > 0) {
    print("Number is positive.")
}
else {
    print("Number is negative.")
}
print("This statement is always executed.")

// nested if else
var number2 = 5
if (number2 >= 0) { // outer if statement
    if (number2 == 0) { // inner if statement
        print("Number is 0")
    }
    else { // inner else statement
        print("Number is positive");
    }
}
else { // outer else statement
    print("Number is negative");
}
