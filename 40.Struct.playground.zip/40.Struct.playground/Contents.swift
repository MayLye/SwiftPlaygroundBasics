import Foundation

// a struct is used to store variables of different data types

// Swift Access Struct Properties
struct Person { // define a structure
// define two properties
 var name = ""
 var age = 0
}
var person1 = Person() // create instance of Person
// access properties and assign new values
person1.age = 21
person1.name = "Pooh"
print("Name: \(person1.name) and Age: \( person1.age) ")


// Create Multiple Instances of Struct
struct Student { // define a structure
    var studentID = 0 // define a property
}
var student1 = Student() // instance of Person
// access properties and assign new values
student1.studentID = 101
print("Student ID: \(student1.studentID)")

var student2 = Student() // another instance of Person
// access properties and assign new values
student2.studentID = 102
print("Student ID: \(student2.studentID)")


// Memberwise Initializer
struct Person2 {
    // properties with no default values
    var name: String
    var age: Int
}
var person2 = Person2(name: "Tigger", age: 19) // instance of Person
print("Name: \(person2.name) and Age: \(person2.age)")


// Function Inside Swift Struct (method)
struct Car {
  var gear = 0
  func applyBrake(){ // method inside struct
  print("Applying Hydraulic Brakes")
  }
}
var car1 = Car() // create an instance
car1.gear = 5
print("Gear Number: \(car1.gear)")
car1.applyBrake() // access method
