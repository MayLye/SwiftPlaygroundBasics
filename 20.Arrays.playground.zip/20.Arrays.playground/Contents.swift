import Foundation

// an array of integer type
var numbers : [Int] = [2, 4, 6, 8]
print("Array: \(numbers)")

// empty array
var value = [Int]()
print(value)

// access array elements
var languages = ["Swift", "Java", "C++"]
print(languages[0]) // access element at index 0
print(languages[2]) // access element at index 2

// Add Elements to an Array
var numbers2 = [21, 34, 54, 12]
print("Before Append: \(numbers2)")
numbers2.append(32) // using append method
print("After Append: \(numbers2)")

// join two arrays
var primeNumbers = [2, 3, 5]
print("Array1: \(primeNumbers)")
var evenNumbers = [4, 6, 8]
print("Array2: \(evenNumbers)")
primeNumbers.append(contentsOf: evenNumbers)
print("Array after append: \(primeNumbers)")

// insert : to add elements at the specified position of an array
var numbers3 = [21, 34, 54, 12]
print("Before Insert: \(numbers3)")
numbers3.insert(32, at: 1)
print("After insert: \(numbers3)")

// Modify the Elements
var dailyActivities = ["Eat","Repeat"]
print("Initial Array: \(dailyActivities)")
dailyActivities[1] = "Sleep" // change element at index 1
print("Updated Array:  \(dailyActivities)")
 
// Remove an Element
var languages2 = ["Swift","Java","Python"]
print("Initial Array: \(languages2)")
let removedValue = languages2.remove(at: 1) // remove element at index 1
print("Updated Array: \(languages2)")
print("Removed value: \(removedValue)")

// Looping Through Array
let fruits = ["Apple", "Peach", "Mango"] // an array of fruits
for fruit in fruits { // for loop to iterate over array
  print(fruit)
}

// Find Number of Array Elements
let evenNumbers2 = [2,4,6,8]
print("Array: \(evenNumbers2)")
print("Total Elements: \(evenNumbers2.count)") // find number of elements

// Check if an Array is Empty
let numbers4 = [21, 33, 59, 17] // array with elements
print("Numbers: \(numbers4)")
var  result = numbers4.isEmpty // check if numbers is empty
print("Is numbers empty? : \(result)")
let evenNumbers3 = [Int]() // array without elements
print("Even Numbers: \(evenNumbers3)")
result = evenNumbers3.isEmpty // check if evenNumbers is empty
print("Is evenNumbers empty? : \(result)")

// Array With Mixed Data Types
var address: [Any] = ["Scranton", 570] // // array with String and integer data
print(address)
