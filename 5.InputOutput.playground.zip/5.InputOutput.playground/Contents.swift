import Foundation

// print statement
print("Good Morning!")
print("It's rainy today")

// print with terminator space
print("Good Morning!", terminator: " ")
print("It's rainy today")

// print() with separator
print("New Year", 2022, "See you soon!", separator: ". ")

// print literals
print(5)

// print variables
var number: Double = -10.6
var name: String = "BigKids"
print(number)
print(name)

// Print Concatenated Strings
print("BigKids is " + "awesome.")

// Print Variables and Strings together
var year = 2014
print("Swift was introduced in \(year)")

// basic input
print("Enter your favorite programming language:")
let name2 = readLine()
print("Your favorite programming language is \(name2)!.")
// got error above.
