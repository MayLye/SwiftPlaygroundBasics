import Foundation

// assign the associated value to the enum value
enum Distance {
  case km(String)   // associate value
  case miles(String)// associate value
}
var dist1 = Distance.km("Metric System") // pass string value to km
print(dist1)
var dist2 = Distance.miles("Imperial System") // pass string value to miles
print(dist2)


// Associate Multiple Values
enum Marks {
case gpa(Double, Double, Double) // associate multiple Double values
case grade(String, String, String) // associate multiple String values
}
var marks1 = Marks.gpa(3.6, 2.9, 3.8) // pass three Double values to gpa
print(marks1)
var marks2 = Marks.grade("A", "B", "C") // pass three string values to grade
print(marks2)


// Named Associated Values
enum Pizza {
  case small (inches: Int) // named associated value
  case medium (inches: Int)// named associated value
  case large (inches: Int) // named associated value
}
var pizza1 = Pizza.medium(inches: 12) // pass value using provided names
print(pizza1)


// enum Associated Values and Switch Statement
enum Mercedes {
 case sedan(height: Double)
 case suv(height: Double)
 case roadster(height: Double)
}
var choice = Mercedes.suv(height: 5.4)
switch(choice) {
  case let .sedan(height):
   print("Height:", height)
  case let .suv(height):
   print("Height:", height)
  case let .roadster(height):
   print("Height:", height)
}


