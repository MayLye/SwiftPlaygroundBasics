import Foundation

/*
 Bitwise shift      >> <<
 Multiplicative     % * /
 Additive           | - + -  ^
 Range              ..< ...
 Casting            is as
 Nil-Coalescing     ??
 Comparison         != > < >= <= === ==
 Logical AND        &&
 Logical OR         ||
 Ternary Operator   ?:
 Assignment Precedence |= %= /= *= >>= <<= ^= += -=
 */

// Operator precedence with the complex assignment operator
var num = 15
num += 10 - 2 * 3
print(num)

// Operator Associativity
print(6 * 4 / 3) 
