import Foundation

var capitalCity = ["France": "Paris", "Italy": "Rome", "England": "London"]
print(capitalCity)

// dictionary with keys and values of different data types
var numbers = [1: "One", 2: "Two", 3: "Three"]
print(numbers)

// Add Elements to a Dictionary
var capitalCity2 = ["Australia": "Sydney", "England": "London"]
print("Initial Dictionary: ",capitalCity2)
capitalCity2["Japan"] = "Tokyo"
print("Updated Dictionary: ",capitalCity2)
print(capitalCity2["Japan"] )

// Change Value of Dictionary
var studentID = [111: "Eric", 112: "Kyle", 113: "Butters"]
print("Initial Dictionary: ", studentID)
studentID[112] = "Stan"
print("Updated Dictionary: ", studentID)

// Access Keys from Dictionary
var cities = ["India":"Delhi", "China":"Beijing", "Japan":"Tokyo"]
print("Dictionary: ", cities)
var countryName  = Array(cities.keys) // cities.keys return all keys of cities
print("Keys: ", countryName)

// Access Keys from Dictionary
var countryName2  = Array(cities.values) // cities.values return all values of cities
print("Values: ", countryName2)

// Remove an Element from a Dictionary
var removedValue  = studentID.removeValue(forKey: 112)
print("Dictionary After removeValue(): ", studentID)

// Iterate Over a Dictionary
var classification = ["Fruit": "Apple", "Vegetable": "Broccoli", "Beverage": "Milk"]
print("Keys: Values")
for (key,value) in classification {
  print("\(key): \(value)")
}

// Find Number of Dictionary Elements
print(studentID.count)

// Empty dictionary
var emptyDictionary =  [Int: String]()
print("Empty Dictionary: ",emptyDictionary)
