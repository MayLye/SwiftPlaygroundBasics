import Foundation

for i in 1...5 { // outer loop
    print(i < 4)
  for j in 1...2 { // inner loop
    print(j < 4)
  }
}

// Swift program to display 7 days of 2 weeks
for week in 1...2 { // outer loop
  print("Week: \(week)")
    for day in 1...7 { // inner loop
      print("  Day:  \(day)")
   }
   print("") // line break after iteration of outer loop
}

// Loop inside a while Loop
// program to display 7 days of 2 weeks
var weeks = 2
var i = 1
while (i <= weeks) { // outer while loop
  print("Week: \(i)")
  for day in 1...7 { // inner for loop
      print("  Day:  \(day)")
    }
    i = i + 1
}

// break inside Nested Loop
for week in 1...3 { // outer loop
  print("Week: \(week)")
  for day in 1...7 { // inner loop
    if(week == 2) { // use of break statement
      break
      }
    print("  Day:  \(day)")
    }
  print("")
}

// continue inside a Nested Loop
for week in 1...2 { // outer loop
  print("Week: \(week)")
  for day in 1...7 { // inner loop
    if(day % 2 != 0) { // use of continue statement
      continue
      }
   print("  Day:  \(day)")
   }
  print("")
}
