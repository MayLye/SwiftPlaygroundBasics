import Foundation

// Optional handling
var someValue:Int?
var someAnotherValue:Int! = 0
        
if someValue != nil {
    print("It has some value \(someValue!)")
} else {
    print("doesn't contain value")
}
        
if someAnotherValue != nil {
    print("It has some value \(someAnotherValue!)")
} else {
    print("doesn't contain value")
}

// Optional binding
var someValue2:Int?
var someAnotherValue2:Int! = 0
       
if let temp = someValue2 {
    print("It has some value \(temp)")
} else {
    print("doesn't contain value")
}
        
if let temp = someAnotherValue2 {
    print("It has some value \(temp)")
} else {
    print("doesn't contain value")
}

// just think of guard as an if-else condition with no if block.
func testFunction() {
    let someValue:Int? = 5
    guard let temp = someValue else {
        return
    }
    print("It has some value \(temp)")
}
testFunction()

// Nil-coalescing operator to check whether a optional contains a value or not
var someValue3:Int? = 10
let defaultValue = 5
let unwrappedValue:Int = someValue3 ?? defaultValue
print(unwrappedValue)
