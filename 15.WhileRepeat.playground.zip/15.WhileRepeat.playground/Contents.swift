import Foundation

// while Loop program to display numbers from 1 to 5
var i = 1, n = 5
while (i <= n) {
  print(i)
   i = i + 1
}

// while Loop to Display Game Level
var currentLevel:Int = 0, finalLevel:Int = 5
let gameCompleted = true
while (currentLevel <= finalLevel) {
  if gameCompleted {
    print("You have passed level \(currentLevel)")
      currentLevel += 1
  }
}
print("Level Ends")

// repeat...while Loop
// var i = 1, n = 5
// repeat...while loop from 1 to 5
repeat {
  print(i)
  i = i + 1
} while (i <= n)
